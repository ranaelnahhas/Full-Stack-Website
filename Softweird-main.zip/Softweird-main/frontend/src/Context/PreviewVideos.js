import createContext from "react"
import React from 'react'
export const PreviewVideos = React.createContext("")