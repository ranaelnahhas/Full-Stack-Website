import createContext from "react"
import React from 'react'
export const Toast = React.createContext("")