import { Box } from "@mui/material";

function VerticalNav (){
    return(
        <nav class="navbar navbar-expand-lg navbar-light bg-light" style={{width:"30%" , left:"-3.5rem" , 
        top:"-4rem",marginBottom:"-5rem"}}>
        </nav>
    )
}
export default VerticalNav