import createContext from "react"
import React from 'react'
export const OneCourseResult = React.createContext("")