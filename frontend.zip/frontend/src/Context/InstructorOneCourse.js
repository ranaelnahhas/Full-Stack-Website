import createContext from "react"
import React from 'react'
export const InstructorOneCourse = React.createContext("")