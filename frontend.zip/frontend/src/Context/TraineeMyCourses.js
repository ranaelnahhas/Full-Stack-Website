import createContext from "react"
import React from 'react'
export const TraineeMyCourses = React.createContext("")